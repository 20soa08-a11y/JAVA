/**
 * 
 */
/**
 * 
 */
module JavaPredavanjaGUI {
	requires java.desktop;
}