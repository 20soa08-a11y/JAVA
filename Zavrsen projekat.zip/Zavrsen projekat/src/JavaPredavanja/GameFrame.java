package JavaPredavanja;


import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class GameFrame extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private static final String FAJL_NEPRIJATELJA = "enemies.txt";
	private static final String FAJL_REZULTATA = "rezultat.txt";

	private final JTextField tfIme = new JTextField();
	private final JTextField tfHealth = new JTextField("100");
	private final JTextField tfX = new JTextField("10");
	private final JTextField tfY = new JTextField("5");
	private final JComboBox<String> cbKolajder = new JComboBox<>(new String[] { "pravougaonik", "kvadrat" });
	private final JTextField tfSirina = new JTextField("40");
	private final JTextField tfVisina = new JTextField("24");
	private final JTextArea taRezultat = new JTextArea();
	private final JButton btnPokreni = new JButton("Pokreni igru");
	private final JButton btnSacuvaj = new JButton("Sačuvaj");

	private Game game;

	public GameFrame() {
		super("Igra - model i logika");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout(10, 10));

		JPanel forma = new JPanel(new GridLayout(0, 2, 5, 5));
		forma.setBorder(BorderFactory.createTitledBorder("Igrač"));
		forma.add(new JLabel("Ime:", SwingConstants.RIGHT));
		forma.add(tfIme);
		forma.add(new JLabel("Početni health (0-100):", SwingConstants.RIGHT));
		forma.add(tfHealth);
		forma.add(new JLabel("Pozicija x:", SwingConstants.RIGHT));
		forma.add(tfX);
		forma.add(new JLabel("Pozicija y:", SwingConstants.RIGHT));
		forma.add(tfY);
		forma.add(new JLabel("Kolajder:", SwingConstants.RIGHT));
		forma.add(cbKolajder);
		forma.add(new JLabel("Širina / stranica:", SwingConstants.RIGHT));
		forma.add(tfSirina);
		forma.add(new JLabel("Visina (samo pravougaonik):", SwingConstants.RIGHT));
		forma.add(tfVisina);

		cbKolajder.addActionListener(e -> tfVisina.setEnabled(cbKolajder.getSelectedIndex() == 0));

		taRezultat.setEditable(false);
		taRezultat.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));

		JPanel dugmad = new JPanel(new GridLayout(1, 2, 10, 10));
		dugmad.add(btnPokreni);
		dugmad.add(btnSacuvaj);

		add(forma, BorderLayout.NORTH);
		add(new JScrollPane(taRezultat), BorderLayout.CENTER);
		add(dugmad, BorderLayout.SOUTH);

		btnPokreni.addActionListener(e -> pokreniIgru());
		btnSacuvaj.addActionListener(e -> sacuvajRezultat());

		setSize(560, 520);
		setLocationRelativeTo(null);
	}

	private void pokreniIgru() {
		try {
			Collidable kolajder = napraviKolajderIzForme();
			Player player = new Player(
					tfIme.getText(),
					Integer.parseInt(tfX.getText().trim()),
					Integer.parseInt(tfY.getText().trim()),
					kolajder,
					Integer.parseInt(tfHealth.getText().trim()));

			ArrayList<Enemy> neprijatelji = Game.loadEnemiesFromFile(FAJL_NEPRIJATELJA);

			game = new Game(player);
			for (Enemy e : neprijatelji) {
				game.addEnemy(e);
			}
			game.resolveCollisions();

			prikaziRezultat();
			JOptionPane.showMessageDialog(this,
					"Status: " + game.getStatus() + "\nHealth na kraju: " + player.getHealth(),
					game.getStatus().equals("POBIJEN") ? "Poražen" : "Preživio",
					JOptionPane.INFORMATION_MESSAGE);
		} catch (NumberFormatException ex) {
			greska("Health, x, y, širina i visina moraju biti cijeli brojevi.");
		} catch (IllegalArgumentException ex) {
			greska(ex.getMessage());
		} catch (IOException ex) {
			greska("Greška pri čitanju fajla " + FAJL_NEPRIJATELJA + ": " + ex.getMessage());
		}
	}

	private Collidable napraviKolajderIzForme() {
		int sirina = Integer.parseInt(tfSirina.getText().trim());
		if (cbKolajder.getSelectedIndex() == 1) {
			return new SquareCollider(sirina);
		}
		int visina = Integer.parseInt(tfVisina.getText().trim());
		return new RectangleCollider(sirina, visina);
	}

	private void sacuvajRezultat() {
		if (game == null) {
			JOptionPane.showMessageDialog(this, "Prvo pokrenite igru.", "Upozorenje",
					JOptionPane.WARNING_MESSAGE);
			return;
		}
		try {
			game.saveToFile(FAJL_REZULTATA);
			JOptionPane.showMessageDialog(this, "Rezultat je sačuvan u " + FAJL_REZULTATA + ".");
		} catch (IOException ex) {
			greska("Greška pri upisu u fajl: " + ex.getMessage());
		}
	}

	private void prikaziRezultat() {
		StringBuilder sb = new StringBuilder();
		sb.append("Igrač: ").append(game.getPlayer()).append("\n");
		sb.append("Status: ").append(game.getStatus()).append("\n\n");

		sb.append("Neprijatelji učitani iz ").append(FAJL_NEPRIJATELJA).append(":\n");
		for (Enemy e : game.getEnemies()) {
			sb.append("  ").append(e).append("\n");
		}

		sb.append("\nNeprijatelji u koliziji:\n");
		ArrayList<Enemy> sudari = game.collidingWithPlayer();
		if (sudari.isEmpty()) {
			sb.append("  nema\n");
		}
		for (Enemy e : sudari) {
			sb.append("  ").append(e).append("\n");
		}

		sb.append("\nLog događaja:\n");
		for (String s : game.getEventLog()) {
			sb.append("  ").append(s).append("\n");
		}
		taRezultat.setText(sb.toString());
		taRezultat.setCaretPosition(0);
	}

	private void greska(String poruka) {
		JOptionPane.showMessageDialog(this, poruka, "Greška", JOptionPane.ERROR_MESSAGE);
	}

	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(() -> new GameFrame().setVisible(true));
	}
}



