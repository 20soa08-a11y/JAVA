package JavaPredavanja;


	public class RectangleCollider implements Collidable {
		private final int width;
		private final int height;

		public RectangleCollider(int width, int height) {
			if (width <= 0 || height <= 0) {
				throw new IllegalArgumentException("Širina i visina pravougaonika moraju biti veće od nule (dobijeno "
						+ width + "x" + height + ")");
			}
			this.width = width;
			this.height = height;
		}

		public int getWidth() {
			return width;
		}

		public int getHeight() {
			return height;
		}

		@Override
		public String toString() {
			return "pravougaonik " + width + "x" + height;
		}
	}



