package JavaPredavanja;

public interface Attacker {

	int getAttackDamage();

	String toString1();
}
