package JavaPredavanja;



	public class BossEnemy extends Enemy {

		public BossEnemy(String type, int x, int y, Collidable collider, int damage, int health) {
			super(type, x, y, collider, damage, health);
		}

		
		@Override
		public int getAttackDamage() {
			return super.getAttackDamage() * 2;
		}
	}