package JavaPredavanja;

public class SquareCollider implements Collidable {
	private final int size;

	public SquareCollider(int size) {
		if (size <= 0) {
			throw new IllegalArgumentException("Stranica kvadrata mora biti veća od nule (dobijeno " + size + ")");
		}
		this.size = size;
	}

	@Override
	public int getWidth() {
		return size;
	}

	@Override
	public int getHeight() {
		return size;
	}

	@Override
	public String toString() {
		return "kvadrat " + size + "x" + size;
	}
}



