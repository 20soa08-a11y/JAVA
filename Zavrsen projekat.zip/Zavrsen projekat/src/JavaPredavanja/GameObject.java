package JavaPredavanja;


	
		
	public abstract class GameObject {
		private int x;
		private int y;
		private final Collidable collider;

		public GameObject(int x, int y, Collidable collider) {
			if (x < 0 || y < 0) {
				throw new IllegalArgumentException("Pozicija ne smije biti negativna (dobijeno " + x + "," + y + ")");
			}
			if (collider == null) {
				throw new IllegalArgumentException("Kolajder ne smije biti null");
			}
			this.x = x;
			this.y = y;
			this.collider = collider;
		}

		public int getX() {
			return x;
		}

		public int getY() {
			return y;
		}

		public void setX(int x) {
			if (x < 0) {
				throw new IllegalArgumentException("X ne smije biti negativan");
			}
			this.x = x;
		}

		public void setY(int y) {
			if (y < 0) {
				throw new IllegalArgumentException("Y ne smije biti negativan");
			}
			this.y = y;
		}

		public Collidable getCollider() {
			return collider;
		}

		
		 
		public boolean intersects(GameObject other) {
			return collider.intersects(x, y, other.collider, other.x, other.y);
		}

		public abstract String getDisplayName();

		@Override
		public String toString() {
			return getDisplayName() + " @ (" + x + "," + y + ") " + collider;
		}

		public String toString1() {
			// TODO Auto-generated method stub
			return null;
		}
	}
