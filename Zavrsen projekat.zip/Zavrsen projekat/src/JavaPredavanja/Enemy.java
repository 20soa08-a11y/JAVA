package JavaPredavanja;

public class Enemy extends GameObject implements Attacker {
	private String type;
	private int damage;
	private int health;

	public Enemy(String type, int x, int y, Collidable collider, int damage, int health) {
		super(x, y, collider);
		setType(type);
		setDamage(damage);
		setHealth(health);
	}

	public String getType() {
		return type;
	}

	public int getDamage() {
		return damage;
	}

	public int getHealth() {
		return health;
	}

	public void setType(String type) {
		if (type == null || type.trim().isEmpty()) {
			throw new IllegalArgumentException("Tip neprijatelja ne smije biti prazan");
		}
		this.type = type.trim();
	}

	public void setDamage(int damage) {
		if (damage < 0 || damage > 100) {
			throw new IllegalArgumentException("Damage mora biti između 0 i 100 (dobijeno " + damage + ")");
		}
		this.damage = damage;
	}

	public void setHealth(int health) {
		if (health < 0 || health > 100) {
			throw new IllegalArgumentException("Health neprijatelja mora biti između 0 i 100 (dobijeno " + health + ")");
		}
		this.health = health;
	}

	@Override
	public int getAttackDamage() {
		return damage;
	}

	@Override
	public String getDisplayName() {
		return type;
	}

	public String toString1() {
		return getClass().getSimpleName() + "[" + type + "] @ (" + getX() + "," + getY() + ") "
				+ getCollider() + " DMG=" + damage + " HP=" + health;
	}



		@Override
		public String toString() {
			return "Enemy[" + type + "] @ (" + getX() + "," + getY() + ") "
					+ getWidth() + "x" + getHeight() + " DMG=" + damage + " HP=" + health;
		}

		private String getHeight() {
			// TODO Auto-generated method stub
			return null;
		}

		
		private String getWidth() {
			// TODO Auto-generated method stub
			return null;
		}
	}


