package JavaPredavanja;



import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Game {
	private final Player player;
	private final ArrayList<Enemy> enemies = new ArrayList<>();
	private final ArrayList<String> eventLog = new ArrayList<>();

	public Game(Player player) {
		if (player == null) {
			throw new IllegalArgumentException("Igrač ne smije biti null");
		}
		this.player = player;
	}

	public Player getPlayer() {
		return player;
	}

	public List<Enemy> getEnemies() {
		return List.copyOf(enemies);
	}

	public List<String> getEventLog() {
		return List.copyOf(eventLog);
	}

	public boolean checkCollision(Player p, Enemy e) {
		return p.intersects(e);
	}

	
	public void decreaseHealth(Player p, Enemy e) {
		int staraHealth = p.getHealth();
		int steta = e.getAttackDamage();
		int novaHealth = Math.max(0, staraHealth - steta);
		p.setHealth(novaHealth);
		eventLog.add("HIT: " + e.getDisplayName() + " for " + steta
				+ " -> HP " + staraHealth + " -> " + novaHealth);
	}

	public void addEnemy(Enemy e) {
		if (e == null) {
			throw new IllegalArgumentException("Neprijatelj ne smije biti null");
		}
		enemies.add(e);
		eventLog.add("ADD: " + e);
	}

	public ArrayList<Enemy> findByType(String query) {
		ArrayList<Enemy> rezultat = new ArrayList<>();
		String trazeno = query.trim().toLowerCase();
		for (Enemy e : enemies) {
			if (e.getType().toLowerCase().contains(trazeno)) {
				rezultat.add(e);
			}
		}
		return rezultat;
	}

	public ArrayList<Enemy> collidingWithPlayer() {
		ArrayList<Enemy> rezultat = new ArrayList<>();
		for (Enemy e : enemies) {
			if (checkCollision(player, e)) {
				rezultat.add(e);
			}
		}
		return rezultat;
	}

	public void resolveCollisions() {
		for (Enemy e : collidingWithPlayer()) {
			decreaseHealth(player, e);
		}
	}

	
	public String getStatus() {
		return player.getHealth() == 0 ? "Igrac"+" "+player+ " "+"je porazen" : "Igrac"+" "+player+" " +"je prezivio";
	}

	
	public static ArrayList<Enemy> loadEnemiesFromFile(String path) throws IOException {
		List<String> linije = Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8);
		ArrayList<Enemy> rezultat = new ArrayList<>();
		for (int i = 1; i < linije.size(); i++) {
			String linija = linije.get(i).trim();
			if (linija.isEmpty()) {
				continue;
			}
			try {
				rezultat.add(parseEnemyLine(linija));
			} catch (IllegalArgumentException ex) {
				throw new IllegalArgumentException("Neispravna linija " + (i + 1) + " u fajlu: " + ex.getMessage(), ex);
			}
		}
		return rezultat;
	}

	
	public static Enemy parseEnemyLine(String linija) {
		String[] dijelovi = linija.split(",");
		if (dijelovi.length != 9) {
			throw new IllegalArgumentException("očekivano 9 polja, dobijeno " + dijelovi.length + ": " + linija);
		}
		String type = dijelovi[0].trim();
		String klasa = dijelovi[1].trim().toLowerCase();
		int damage = Integer.parseInt(dijelovi[2].trim());
		int health = Integer.parseInt(dijelovi[3].trim());
		int x = Integer.parseInt(dijelovi[4].trim());
		int y = Integer.parseInt(dijelovi[5].trim());
		String oblik = dijelovi[6].trim().toLowerCase();
		int sirina = Integer.parseInt(dijelovi[7].trim());
		int visina = Integer.parseInt(dijelovi[8].trim());

		Collidable kolajder = napraviKolajder(oblik, sirina, visina);

		switch (klasa) {
			case "melee":
				return new MeleeEnemy(type, x, y, kolajder, damage, health);
			case "boss":
				return new BossEnemy(type, x, y, kolajder, damage, health);
			default:
				throw new IllegalArgumentException("nepoznata klasa neprijatelja '" + klasa + "'");
		}
	}

	
	public static Collidable napraviKolajder(String oblik, int sirina, int visina) {
		switch (oblik.toLowerCase()) {
			case "square":
			case "kvadrat":
				if (sirina != visina) {
					throw new IllegalArgumentException("kvadrat mora imati jednake stranice (dobijeno "
							+ sirina + "x" + visina + ")");
				}
				return new SquareCollider(sirina);
			case "rectangle":
			case "pravougaonik":
				return new RectangleCollider(sirina, visina);
			default:
				throw new IllegalArgumentException("nepoznat oblik kolajdera '" + oblik + "'");
		}
	}

	
	public void saveToFile(String path) throws IOException {
		ArrayList<String> linije = new ArrayList<>();
		linije.add("REZULTAT IGRE");
		linije.add("Igrač: " + player);
		linije.add("Status: " + getStatus());
		linije.add("");
		linije.add("Neprijatelji u koliziji:");
		ArrayList<Enemy> sudari = collidingWithPlayer();
		if (sudari.isEmpty()) {
			linije.add("  nema");
		}
		for (Enemy e : sudari) {
			linije.add("  " + e);
		}
		linije.add("");
		linije.add("Log događaja:");
		linije.addAll(eventLog);
		Files.write(Paths.get(path), linije, StandardCharsets.UTF_8);
	}


	public static void main(String[] args) {
		GameFrame.main(args);
	}
}